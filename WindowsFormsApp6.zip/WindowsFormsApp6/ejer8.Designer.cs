﻿namespace WindowsFormsApp6
{
    partial class a
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(a));
            this.button1 = new System.Windows.Forms.Button();
            this.p6 = new System.Windows.Forms.PictureBox();
            this.p5 = new System.Windows.Forms.PictureBox();
            this.p4 = new System.Windows.Forms.PictureBox();
            this.p3 = new System.Windows.Forms.PictureBox();
            this.p2 = new System.Windows.Forms.PictureBox();
            this.p1 = new System.Windows.Forms.PictureBox();
            this.t1 = new System.Windows.Forms.PictureBox();
            this.t2 = new System.Windows.Forms.PictureBox();
            this.t3 = new System.Windows.Forms.PictureBox();
            this.t4 = new System.Windows.Forms.PictureBox();
            this.t5 = new System.Windows.Forms.PictureBox();
            this.t6 = new System.Windows.Forms.PictureBox();
            this.q1 = new System.Windows.Forms.PictureBox();
            this.q2 = new System.Windows.Forms.PictureBox();
            this.q3 = new System.Windows.Forms.PictureBox();
            this.q4 = new System.Windows.Forms.PictureBox();
            this.q5 = new System.Windows.Forms.PictureBox();
            this.q6 = new System.Windows.Forms.PictureBox();
            this.x1 = new System.Windows.Forms.PictureBox();
            this.x2 = new System.Windows.Forms.PictureBox();
            this.x3 = new System.Windows.Forms.PictureBox();
            this.x4 = new System.Windows.Forms.PictureBox();
            this.x5 = new System.Windows.Forms.PictureBox();
            this.x6 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.p6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.q1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.q2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.q3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.q4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.q5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.q6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x6)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(28, 183);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "TIRA LOS DADOS";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // p6
            // 
            this.p6.Image = ((System.Drawing.Image)(resources.GetObject("p6.Image")));
            this.p6.Location = new System.Drawing.Point(323, 12);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(174, 165);
            this.p6.TabIndex = 2;
            this.p6.TabStop = false;
            // 
            // p5
            // 
            this.p5.Image = ((System.Drawing.Image)(resources.GetObject("p5.Image")));
            this.p5.Location = new System.Drawing.Point(323, 14);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(174, 165);
            this.p5.TabIndex = 5;
            this.p5.TabStop = false;
            // 
            // p4
            // 
            this.p4.Image = ((System.Drawing.Image)(resources.GetObject("p4.Image")));
            this.p4.Location = new System.Drawing.Point(323, 12);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(174, 165);
            this.p4.TabIndex = 9;
            this.p4.TabStop = false;
            // 
            // p3
            // 
            this.p3.Image = ((System.Drawing.Image)(resources.GetObject("p3.Image")));
            this.p3.Location = new System.Drawing.Point(323, 14);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(174, 165);
            this.p3.TabIndex = 13;
            this.p3.TabStop = false;
            // 
            // p2
            // 
            this.p2.Image = ((System.Drawing.Image)(resources.GetObject("p2.Image")));
            this.p2.Location = new System.Drawing.Point(323, 14);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(174, 165);
            this.p2.TabIndex = 17;
            this.p2.TabStop = false;
            // 
            // p1
            // 
            this.p1.Image = ((System.Drawing.Image)(resources.GetObject("p1.Image")));
            this.p1.Location = new System.Drawing.Point(323, 14);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(174, 165);
            this.p1.TabIndex = 21;
            this.p1.TabStop = false;
            // 
            // t1
            // 
            this.t1.Image = ((System.Drawing.Image)(resources.GetObject("t1.Image")));
            this.t1.Location = new System.Drawing.Point(503, 14);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(174, 165);
            this.t1.TabIndex = 27;
            this.t1.TabStop = false;
            // 
            // t2
            // 
            this.t2.Image = ((System.Drawing.Image)(resources.GetObject("t2.Image")));
            this.t2.Location = new System.Drawing.Point(503, 14);
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(174, 165);
            this.t2.TabIndex = 26;
            this.t2.TabStop = false;
            // 
            // t3
            // 
            this.t3.Image = ((System.Drawing.Image)(resources.GetObject("t3.Image")));
            this.t3.Location = new System.Drawing.Point(503, 12);
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(174, 165);
            this.t3.TabIndex = 25;
            this.t3.TabStop = false;
            // 
            // t4
            // 
            this.t4.Image = ((System.Drawing.Image)(resources.GetObject("t4.Image")));
            this.t4.Location = new System.Drawing.Point(503, 12);
            this.t4.Name = "t4";
            this.t4.Size = new System.Drawing.Size(174, 165);
            this.t4.TabIndex = 24;
            this.t4.TabStop = false;
            // 
            // t5
            // 
            this.t5.Image = ((System.Drawing.Image)(resources.GetObject("t5.Image")));
            this.t5.Location = new System.Drawing.Point(503, 12);
            this.t5.Name = "t5";
            this.t5.Size = new System.Drawing.Size(174, 165);
            this.t5.TabIndex = 23;
            this.t5.TabStop = false;
            // 
            // t6
            // 
            this.t6.Image = ((System.Drawing.Image)(resources.GetObject("t6.Image")));
            this.t6.Location = new System.Drawing.Point(503, 12);
            this.t6.Name = "t6";
            this.t6.Size = new System.Drawing.Size(174, 165);
            this.t6.TabIndex = 22;
            this.t6.TabStop = false;
            // 
            // q1
            // 
            this.q1.Image = ((System.Drawing.Image)(resources.GetObject("q1.Image")));
            this.q1.Location = new System.Drawing.Point(323, 183);
            this.q1.Name = "q1";
            this.q1.Size = new System.Drawing.Size(174, 165);
            this.q1.TabIndex = 33;
            this.q1.TabStop = false;
            // 
            // q2
            // 
            this.q2.Image = ((System.Drawing.Image)(resources.GetObject("q2.Image")));
            this.q2.Location = new System.Drawing.Point(323, 183);
            this.q2.Name = "q2";
            this.q2.Size = new System.Drawing.Size(174, 165);
            this.q2.TabIndex = 32;
            this.q2.TabStop = false;
            // 
            // q3
            // 
            this.q3.Image = ((System.Drawing.Image)(resources.GetObject("q3.Image")));
            this.q3.Location = new System.Drawing.Point(323, 183);
            this.q3.Name = "q3";
            this.q3.Size = new System.Drawing.Size(174, 165);
            this.q3.TabIndex = 31;
            this.q3.TabStop = false;
            // 
            // q4
            // 
            this.q4.Image = ((System.Drawing.Image)(resources.GetObject("q4.Image")));
            this.q4.Location = new System.Drawing.Point(323, 183);
            this.q4.Name = "q4";
            this.q4.Size = new System.Drawing.Size(174, 165);
            this.q4.TabIndex = 30;
            this.q4.TabStop = false;
            // 
            // q5
            // 
            this.q5.Image = ((System.Drawing.Image)(resources.GetObject("q5.Image")));
            this.q5.Location = new System.Drawing.Point(323, 183);
            this.q5.Name = "q5";
            this.q5.Size = new System.Drawing.Size(174, 165);
            this.q5.TabIndex = 29;
            this.q5.TabStop = false;
            // 
            // q6
            // 
            this.q6.Image = ((System.Drawing.Image)(resources.GetObject("q6.Image")));
            this.q6.Location = new System.Drawing.Point(323, 183);
            this.q6.Name = "q6";
            this.q6.Size = new System.Drawing.Size(174, 165);
            this.q6.TabIndex = 28;
            this.q6.TabStop = false;
            // 
            // x1
            // 
            this.x1.Image = ((System.Drawing.Image)(resources.GetObject("x1.Image")));
            this.x1.Location = new System.Drawing.Point(503, 185);
            this.x1.Name = "x1";
            this.x1.Size = new System.Drawing.Size(174, 165);
            this.x1.TabIndex = 39;
            this.x1.TabStop = false;
            // 
            // x2
            // 
            this.x2.Image = ((System.Drawing.Image)(resources.GetObject("x2.Image")));
            this.x2.Location = new System.Drawing.Point(503, 185);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(174, 165);
            this.x2.TabIndex = 38;
            this.x2.TabStop = false;
            // 
            // x3
            // 
            this.x3.Image = ((System.Drawing.Image)(resources.GetObject("x3.Image")));
            this.x3.Location = new System.Drawing.Point(503, 183);
            this.x3.Name = "x3";
            this.x3.Size = new System.Drawing.Size(174, 165);
            this.x3.TabIndex = 37;
            this.x3.TabStop = false;
            // 
            // x4
            // 
            this.x4.Image = ((System.Drawing.Image)(resources.GetObject("x4.Image")));
            this.x4.Location = new System.Drawing.Point(503, 183);
            this.x4.Name = "x4";
            this.x4.Size = new System.Drawing.Size(174, 165);
            this.x4.TabIndex = 36;
            this.x4.TabStop = false;
            // 
            // x5
            // 
            this.x5.Image = ((System.Drawing.Image)(resources.GetObject("x5.Image")));
            this.x5.Location = new System.Drawing.Point(503, 185);
            this.x5.Name = "x5";
            this.x5.Size = new System.Drawing.Size(174, 165);
            this.x5.TabIndex = 35;
            this.x5.TabStop = false;
            // 
            // x6
            // 
            this.x6.Image = ((System.Drawing.Image)(resources.GetObject("x6.Image")));
            this.x6.Location = new System.Drawing.Point(503, 185);
            this.x6.Name = "x6";
            this.x6.Size = new System.Drawing.Size(174, 165);
            this.x6.TabIndex = 34;
            this.x6.TabStop = false;
            // 
            // a
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.x1);
            this.Controls.Add(this.x2);
            this.Controls.Add(this.x3);
            this.Controls.Add(this.x4);
            this.Controls.Add(this.x5);
            this.Controls.Add(this.x6);
            this.Controls.Add(this.q1);
            this.Controls.Add(this.q2);
            this.Controls.Add(this.q3);
            this.Controls.Add(this.q4);
            this.Controls.Add(this.q5);
            this.Controls.Add(this.q6);
            this.Controls.Add(this.t1);
            this.Controls.Add(this.t2);
            this.Controls.Add(this.t3);
            this.Controls.Add(this.t4);
            this.Controls.Add(this.t5);
            this.Controls.Add(this.t6);
            this.Controls.Add(this.p1);
            this.Controls.Add(this.p2);
            this.Controls.Add(this.p3);
            this.Controls.Add(this.p4);
            this.Controls.Add(this.p5);
            this.Controls.Add(this.p6);
            this.Controls.Add(this.button1);
            this.Name = "a";
            this.Text = "ejer8";
            ((System.ComponentModel.ISupportInitialize)(this.p6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.q1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.q2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.q3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.q4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.q5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.q6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox p6;
        private System.Windows.Forms.PictureBox p5;
        private System.Windows.Forms.PictureBox p4;
        private System.Windows.Forms.PictureBox p3;
        private System.Windows.Forms.PictureBox p2;
        private System.Windows.Forms.PictureBox p1;
        private System.Windows.Forms.PictureBox t1;
        private System.Windows.Forms.PictureBox t2;
        private System.Windows.Forms.PictureBox t3;
        private System.Windows.Forms.PictureBox t4;
        private System.Windows.Forms.PictureBox t5;
        private System.Windows.Forms.PictureBox t6;
        private System.Windows.Forms.PictureBox q1;
        private System.Windows.Forms.PictureBox q2;
        private System.Windows.Forms.PictureBox q3;
        private System.Windows.Forms.PictureBox q4;
        private System.Windows.Forms.PictureBox q5;
        private System.Windows.Forms.PictureBox q6;
        private System.Windows.Forms.PictureBox x1;
        private System.Windows.Forms.PictureBox x2;
        private System.Windows.Forms.PictureBox x3;
        private System.Windows.Forms.PictureBox x4;
        private System.Windows.Forms.PictureBox x5;
        private System.Windows.Forms.PictureBox x6;
    }
}