﻿namespace WindowsFormsApp6
{
    partial class ejer9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ejer9));
            this.radiocremas = new System.Windows.Forms.RadioButton();
            this.radioensaladas = new System.Windows.Forms.RadioButton();
            this.radioempanadas = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.comboplatosprinci = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblprecio = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblprecio2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.combosegundoplato = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.radiocafe = new System.Windows.Forms.RadioButton();
            this.radiopostre = new System.Windows.Forms.RadioButton();
            this.combopostre = new System.Windows.Forms.ComboBox();
            this.combocafe = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lblpreciocafe = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblpreciopostre = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblpreciototal = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.lblpreciobebida = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // radiocremas
            // 
            this.radiocremas.AutoSize = true;
            this.radiocremas.BackColor = System.Drawing.SystemColors.InfoText;
            this.radiocremas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radiocremas.Location = new System.Drawing.Point(62, 102);
            this.radiocremas.Name = "radiocremas";
            this.radiocremas.Size = new System.Drawing.Size(60, 17);
            this.radiocremas.TabIndex = 0;
            this.radiocremas.TabStop = true;
            this.radiocremas.Text = "Cremas";
            this.radiocremas.UseVisualStyleBackColor = false;
            this.radiocremas.CheckedChanged += new System.EventHandler(this.radiocremas_CheckedChanged);
            // 
            // radioensaladas
            // 
            this.radioensaladas.AutoSize = true;
            this.radioensaladas.BackColor = System.Drawing.SystemColors.InfoText;
            this.radioensaladas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioensaladas.Location = new System.Drawing.Point(62, 125);
            this.radioensaladas.Name = "radioensaladas";
            this.radioensaladas.Size = new System.Drawing.Size(74, 17);
            this.radioensaladas.TabIndex = 1;
            this.radioensaladas.TabStop = true;
            this.radioensaladas.Text = "Ensaladas";
            this.radioensaladas.UseVisualStyleBackColor = false;
            this.radioensaladas.CheckedChanged += new System.EventHandler(this.radioensaladas_CheckedChanged);
            // 
            // radioempanadas
            // 
            this.radioempanadas.AutoSize = true;
            this.radioempanadas.BackColor = System.Drawing.SystemColors.InfoText;
            this.radioempanadas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioempanadas.Location = new System.Drawing.Point(62, 148);
            this.radioempanadas.Name = "radioempanadas";
            this.radioempanadas.Size = new System.Drawing.Size(81, 17);
            this.radioempanadas.TabIndex = 2;
            this.radioempanadas.TabStop = true;
            this.radioempanadas.Text = "Empanadas";
            this.radioempanadas.UseVisualStyleBackColor = false;
            this.radioempanadas.CheckedChanged += new System.EventHandler(this.radioempanadas_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(57, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Plato Principal";
            // 
            // comboplatosprinci
            // 
            this.comboplatosprinci.BackColor = System.Drawing.SystemColors.InfoText;
            this.comboplatosprinci.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboplatosprinci.ForeColor = System.Drawing.SystemColors.Info;
            this.comboplatosprinci.FormattingEnabled = true;
            this.comboplatosprinci.Location = new System.Drawing.Point(166, 121);
            this.comboplatosprinci.Name = "comboplatosprinci";
            this.comboplatosprinci.Size = new System.Drawing.Size(121, 21);
            this.comboplatosprinci.TabIndex = 4;
            this.comboplatosprinci.SelectedIndexChanged += new System.EventHandler(this.comboplatosprinci_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(57, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Precio:";
            // 
            // lblprecio
            // 
            this.lblprecio.AutoSize = true;
            this.lblprecio.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprecio.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblprecio.Location = new System.Drawing.Point(161, 198);
            this.lblprecio.Name = "lblprecio";
            this.lblprecio.Size = new System.Drawing.Size(0, 25);
            this.lblprecio.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(221, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "€";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(423, 303);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 25);
            this.label4.TabIndex = 15;
            this.label4.Text = "€";
            this.label4.Visible = false;
            // 
            // lblprecio2
            // 
            this.lblprecio2.AutoSize = true;
            this.lblprecio2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprecio2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblprecio2.Location = new System.Drawing.Point(363, 303);
            this.lblprecio2.Name = "lblprecio2";
            this.lblprecio2.Size = new System.Drawing.Size(0, 25);
            this.lblprecio2.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(259, 303);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "Precio:";
            // 
            // combosegundoplato
            // 
            this.combosegundoplato.BackColor = System.Drawing.SystemColors.InfoText;
            this.combosegundoplato.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.combosegundoplato.ForeColor = System.Drawing.SystemColors.Info;
            this.combosegundoplato.FormattingEnabled = true;
            this.combosegundoplato.Location = new System.Drawing.Point(368, 226);
            this.combosegundoplato.Name = "combosegundoplato";
            this.combosegundoplato.Size = new System.Drawing.Size(121, 21);
            this.combosegundoplato.TabIndex = 12;
            this.combosegundoplato.SelectedIndexChanged += new System.EventHandler(this.combosegundoplato_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(259, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 25);
            this.label7.TabIndex = 11;
            this.label7.Text = "Segundo Plato";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.SystemColors.InfoText;
            this.radioButton1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioButton1.Location = new System.Drawing.Point(264, 253);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(52, 17);
            this.radioButton1.TabIndex = 10;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Pasta";
            this.radioButton1.UseVisualStyleBackColor = false;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.BackColor = System.Drawing.SystemColors.InfoText;
            this.radioButton2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioButton2.Location = new System.Drawing.Point(264, 230);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(53, 17);
            this.radioButton2.TabIndex = 9;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Carne";
            this.radioButton2.UseVisualStyleBackColor = false;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.BackColor = System.Drawing.SystemColors.InfoText;
            this.radioButton3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioButton3.Location = new System.Drawing.Point(264, 207);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(67, 17);
            this.radioButton3.TabIndex = 8;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Pescado";
            this.radioButton3.UseVisualStyleBackColor = false;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(528, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(155, 25);
            this.label5.TabIndex = 18;
            this.label5.Text = "Café || Postre";
            // 
            // radiocafe
            // 
            this.radiocafe.AutoSize = true;
            this.radiocafe.BackColor = System.Drawing.SystemColors.InfoText;
            this.radiocafe.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radiocafe.Location = new System.Drawing.Point(533, 284);
            this.radiocafe.Name = "radiocafe";
            this.radiocafe.Size = new System.Drawing.Size(50, 17);
            this.radiocafe.TabIndex = 17;
            this.radiocafe.TabStop = true;
            this.radiocafe.Text = "Carfé";
            this.radiocafe.UseVisualStyleBackColor = false;
            this.radiocafe.CheckedChanged += new System.EventHandler(this.radiocafe_CheckedChanged);
            // 
            // radiopostre
            // 
            this.radiopostre.AutoSize = true;
            this.radiopostre.BackColor = System.Drawing.SystemColors.InfoText;
            this.radiopostre.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radiopostre.Location = new System.Drawing.Point(533, 174);
            this.radiopostre.Name = "radiopostre";
            this.radiopostre.Size = new System.Drawing.Size(55, 17);
            this.radiopostre.TabIndex = 16;
            this.radiopostre.TabStop = true;
            this.radiopostre.Text = "Postre";
            this.radiopostre.UseVisualStyleBackColor = false;
            this.radiopostre.CheckedChanged += new System.EventHandler(this.radiopostre_CheckedChanged);
            // 
            // combopostre
            // 
            this.combopostre.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.combopostre.ForeColor = System.Drawing.SystemColors.Info;
            this.combopostre.FormattingEnabled = true;
            this.combopostre.Location = new System.Drawing.Point(533, 201);
            this.combopostre.Name = "combopostre";
            this.combopostre.Size = new System.Drawing.Size(121, 21);
            this.combopostre.TabIndex = 19;
            this.combopostre.SelectedIndexChanged += new System.EventHandler(this.combopostre_SelectedIndexChanged);
            // 
            // combocafe
            // 
            this.combocafe.BackColor = System.Drawing.SystemColors.InfoText;
            this.combocafe.ForeColor = System.Drawing.SystemColors.Info;
            this.combocafe.FormattingEnabled = true;
            this.combocafe.Location = new System.Drawing.Point(533, 309);
            this.combocafe.Name = "combocafe";
            this.combocafe.Size = new System.Drawing.Size(121, 21);
            this.combocafe.TabIndex = 20;
            this.combocafe.SelectedIndexChanged += new System.EventHandler(this.combocafe_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(692, 333);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 25);
            this.label8.TabIndex = 23;
            this.label8.Text = "€";
            this.label8.Visible = false;
            // 
            // lblpreciocafe
            // 
            this.lblpreciocafe.AutoSize = true;
            this.lblpreciocafe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpreciocafe.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblpreciocafe.Location = new System.Drawing.Point(632, 333);
            this.lblpreciocafe.Name = "lblpreciocafe";
            this.lblpreciocafe.Size = new System.Drawing.Size(0, 25);
            this.lblpreciocafe.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(528, 343);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 25);
            this.label10.TabIndex = 21;
            this.label10.Text = "Precio:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(692, 246);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 25);
            this.label11.TabIndex = 26;
            this.label11.Text = "€";
            this.label11.Visible = false;
            // 
            // lblpreciopostre
            // 
            this.lblpreciopostre.AutoSize = true;
            this.lblpreciopostre.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpreciopostre.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblpreciopostre.Location = new System.Drawing.Point(632, 246);
            this.lblpreciopostre.Name = "lblpreciopostre";
            this.lblpreciopostre.Size = new System.Drawing.Size(0, 25);
            this.lblpreciopostre.TabIndex = 25;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label13.Location = new System.Drawing.Point(528, 246);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 25);
            this.label13.TabIndex = 24;
            this.label13.Text = "Precio:";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.BackColor = System.Drawing.SystemColors.InfoText;
            this.radioButton4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioButton4.Location = new System.Drawing.Point(521, 82);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(46, 17);
            this.radioButton4.TabIndex = 29;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Vino";
            this.radioButton4.UseVisualStyleBackColor = false;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.BackColor = System.Drawing.SystemColors.InfoText;
            this.radioButton5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioButton5.Location = new System.Drawing.Point(521, 59);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(68, 17);
            this.radioButton5.TabIndex = 28;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Refresco";
            this.radioButton5.UseVisualStyleBackColor = false;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.BackColor = System.Drawing.SystemColors.InfoText;
            this.radioButton6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioButton6.Location = new System.Drawing.Point(521, 36);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(50, 17);
            this.radioButton6.TabIndex = 27;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Agua";
            this.radioButton6.UseVisualStyleBackColor = false;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(516, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(165, 25);
            this.label9.TabIndex = 30;
            this.label9.Text = "Plato Principal";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(240, 344);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 25);
            this.label12.TabIndex = 33;
            this.label12.Text = "€";
            this.label12.Visible = false;
            // 
            // lblpreciototal
            // 
            this.lblpreciototal.AutoSize = true;
            this.lblpreciototal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpreciototal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblpreciototal.Location = new System.Drawing.Point(173, 343);
            this.lblpreciototal.Name = "lblpreciototal";
            this.lblpreciototal.Size = new System.Drawing.Size(0, 25);
            this.lblpreciototal.TabIndex = 32;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label15.Location = new System.Drawing.Point(2, 343);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(146, 25);
            this.label15.TabIndex = 31;
            this.label15.Text = "Precio Total:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(280, 344);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 34;
            this.button1.Text = "Finalizar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label14.Location = new System.Drawing.Point(724, 82);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(25, 25);
            this.label14.TabIndex = 37;
            this.label14.Text = "€";
            this.label14.Visible = false;
            // 
            // lblpreciobebida
            // 
            this.lblpreciobebida.AutoSize = true;
            this.lblpreciobebida.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpreciobebida.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblpreciobebida.Location = new System.Drawing.Point(686, 82);
            this.lblpreciobebida.Name = "lblpreciobebida";
            this.lblpreciobebida.Size = new System.Drawing.Size(0, 25);
            this.lblpreciobebida.TabIndex = 36;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label17.Location = new System.Drawing.Point(582, 82);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 25);
            this.label17.TabIndex = 35;
            this.label17.Text = "Precio:";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.InfoText;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(807, 174);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 36);
            this.button2.TabIndex = 38;
            this.button2.Text = "Calcular cambio";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(786, 148);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 39;
            this.textBox1.Visible = false;
            this.textBox1.WordWrap = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(783, 226);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 16);
            this.label16.TabIndex = 40;
            this.label16.Text = "Cambio:";
            this.label16.Visible = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(862, 228);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 13);
            this.label18.TabIndex = 41;
            this.label18.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label19.Location = new System.Drawing.Point(890, 217);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(25, 25);
            this.label19.TabIndex = 42;
            this.label19.Text = "€";
            this.label19.Visible = false;
            // 
            // ejer9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(916, 450);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblpreciobebida);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lblpreciototal);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton5);
            this.Controls.Add(this.radioButton6);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblpreciopostre);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblpreciocafe);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.combocafe);
            this.Controls.Add(this.combopostre);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.radiocafe);
            this.Controls.Add(this.radiopostre);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblprecio2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.combosegundoplato);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblprecio);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboplatosprinci);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioempanadas);
            this.Controls.Add(this.radioensaladas);
            this.Controls.Add(this.radiocremas);
            this.Name = "ejer9";
            this.Text = "ejer9";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radiocremas;
        private System.Windows.Forms.RadioButton radioensaladas;
        private System.Windows.Forms.RadioButton radioempanadas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboplatosprinci;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblprecio;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblprecio2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox combosegundoplato;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radiocafe;
        private System.Windows.Forms.RadioButton radiopostre;
        private System.Windows.Forms.ComboBox combopostre;
        private System.Windows.Forms.ComboBox combocafe;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblpreciocafe;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblpreciopostre;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblpreciototal;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblpreciobebida;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
    }
}