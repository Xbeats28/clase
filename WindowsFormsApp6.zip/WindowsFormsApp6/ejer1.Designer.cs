﻿namespace WindowsFormsApp6
{
    partial class ejer1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comprobador1 = new System.Windows.Forms.CheckBox();
            this.precio1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.precio2 = new System.Windows.Forms.Label();
            this.comprobador2 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.precio3 = new System.Windows.Forms.Label();
            this.comprobador3 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.precio6 = new System.Windows.Forms.Label();
            this.comprobador6 = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.precio5 = new System.Windows.Forms.Label();
            this.comprobador5 = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.precio4 = new System.Windows.Forms.Label();
            this.comprobador4 = new System.Windows.Forms.CheckBox();
            this.btncalcular = new System.Windows.Forms.Button();
            this.btncancelar = new System.Windows.Forms.Button();
            this.lbltotal = new System.Windows.Forms.Label();
            this.lblresultado = new System.Windows.Forms.Label();
            this.btnsalir = new System.Windows.Forms.Button();
            this.cantidad1 = new System.Windows.Forms.NumericUpDown();
            this.cantidad2 = new System.Windows.Forms.NumericUpDown();
            this.cantidad3 = new System.Windows.Forms.NumericUpDown();
            this.cantidad6 = new System.Windows.Forms.NumericUpDown();
            this.cantidad5 = new System.Windows.Forms.NumericUpDown();
            this.cantidad4 = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad4)).BeginInit();
            this.SuspendLayout();
            // 
            // comprobador1
            // 
            this.comprobador1.AutoSize = true;
            this.comprobador1.Location = new System.Drawing.Point(217, 78);
            this.comprobador1.Name = "comprobador1";
            this.comprobador1.Size = new System.Drawing.Size(15, 14);
            this.comprobador1.TabIndex = 0;
            this.comprobador1.UseVisualStyleBackColor = true;
            // 
            // precio1
            // 
            this.precio1.AutoSize = true;
            this.precio1.Location = new System.Drawing.Point(176, 78);
            this.precio1.Name = "precio1";
            this.precio1.Size = new System.Drawing.Size(25, 13);
            this.precio1.TabIndex = 1;
            this.precio1.Text = "500";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Portatil";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(107, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Calculadora";
            // 
            // precio2
            // 
            this.precio2.AutoSize = true;
            this.precio2.Location = new System.Drawing.Point(176, 107);
            this.precio2.Name = "precio2";
            this.precio2.Size = new System.Drawing.Size(19, 13);
            this.precio2.TabIndex = 4;
            this.precio2.Text = "25";
            // 
            // comprobador2
            // 
            this.comprobador2.AutoSize = true;
            this.comprobador2.Location = new System.Drawing.Point(217, 107);
            this.comprobador2.Name = "comprobador2";
            this.comprobador2.Size = new System.Drawing.Size(15, 14);
            this.comprobador2.TabIndex = 3;
            this.comprobador2.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(127, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Enchufe";
            // 
            // precio3
            // 
            this.precio3.AutoSize = true;
            this.precio3.Location = new System.Drawing.Point(176, 136);
            this.precio3.Name = "precio3";
            this.precio3.Size = new System.Drawing.Size(19, 13);
            this.precio3.TabIndex = 7;
            this.precio3.Text = "29";
            // 
            // comprobador3
            // 
            this.comprobador3.AutoSize = true;
            this.comprobador3.Location = new System.Drawing.Point(217, 136);
            this.comprobador3.Name = "comprobador3";
            this.comprobador3.Size = new System.Drawing.Size(15, 14);
            this.comprobador3.TabIndex = 6;
            this.comprobador3.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(338, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Intermitente";
            // 
            // precio6
            // 
            this.precio6.AutoSize = true;
            this.precio6.Location = new System.Drawing.Point(395, 137);
            this.precio6.Name = "precio6";
            this.precio6.Size = new System.Drawing.Size(19, 13);
            this.precio6.TabIndex = 16;
            this.precio6.Text = "18";
            // 
            // comprobador6
            // 
            this.comprobador6.AutoSize = true;
            this.comprobador6.Location = new System.Drawing.Point(430, 136);
            this.comprobador6.Name = "comprobador6";
            this.comprobador6.Size = new System.Drawing.Size(15, 14);
            this.comprobador6.TabIndex = 15;
            this.comprobador6.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(348, 107);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Luz";
            // 
            // precio5
            // 
            this.precio5.AutoSize = true;
            this.precio5.Location = new System.Drawing.Point(389, 107);
            this.precio5.Name = "precio5";
            this.precio5.Size = new System.Drawing.Size(19, 13);
            this.precio5.TabIndex = 13;
            this.precio5.Text = "19";
            // 
            // comprobador5
            // 
            this.comprobador5.AutoSize = true;
            this.comprobador5.Location = new System.Drawing.Point(430, 107);
            this.comprobador5.Name = "comprobador5";
            this.comprobador5.Size = new System.Drawing.Size(15, 14);
            this.comprobador5.TabIndex = 12;
            this.comprobador5.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(338, 78);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Ventana";
            // 
            // precio4
            // 
            this.precio4.AutoSize = true;
            this.precio4.Location = new System.Drawing.Point(389, 78);
            this.precio4.Name = "precio4";
            this.precio4.Size = new System.Drawing.Size(25, 13);
            this.precio4.TabIndex = 10;
            this.precio4.Text = "125";
            // 
            // comprobador4
            // 
            this.comprobador4.AutoSize = true;
            this.comprobador4.Location = new System.Drawing.Point(430, 78);
            this.comprobador4.Name = "comprobador4";
            this.comprobador4.Size = new System.Drawing.Size(15, 14);
            this.comprobador4.TabIndex = 9;
            this.comprobador4.UseVisualStyleBackColor = true;
            // 
            // btncalcular
            // 
            this.btncalcular.Location = new System.Drawing.Point(330, 211);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(75, 23);
            this.btncalcular.TabIndex = 18;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // btncancelar
            // 
            this.btncancelar.Location = new System.Drawing.Point(411, 210);
            this.btncancelar.Name = "btncancelar";
            this.btncancelar.Size = new System.Drawing.Size(75, 23);
            this.btncancelar.TabIndex = 19;
            this.btncancelar.Text = "Cancelar";
            this.btncancelar.UseVisualStyleBackColor = true;
            this.btncancelar.Click += new System.EventHandler(this.btncancelar_Click);
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Location = new System.Drawing.Point(119, 220);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(0, 13);
            this.lbltotal.TabIndex = 20;
            // 
            // lblresultado
            // 
            this.lblresultado.AutoSize = true;
            this.lblresultado.Location = new System.Drawing.Point(161, 220);
            this.lblresultado.Name = "lblresultado";
            this.lblresultado.Size = new System.Drawing.Size(0, 13);
            this.lblresultado.TabIndex = 21;
            // 
            // btnsalir
            // 
            this.btnsalir.Location = new System.Drawing.Point(411, 240);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(75, 23);
            this.btnsalir.TabIndex = 22;
            this.btnsalir.Text = "Salir";
            this.btnsalir.UseVisualStyleBackColor = true;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // cantidad1
            // 
            this.cantidad1.Location = new System.Drawing.Point(238, 73);
            this.cantidad1.Name = "cantidad1";
            this.cantidad1.Size = new System.Drawing.Size(50, 20);
            this.cantidad1.TabIndex = 23;
            // 
            // cantidad2
            // 
            this.cantidad2.Location = new System.Drawing.Point(238, 105);
            this.cantidad2.Name = "cantidad2";
            this.cantidad2.Size = new System.Drawing.Size(50, 20);
            this.cantidad2.TabIndex = 24;
            // 
            // cantidad3
            // 
            this.cantidad3.Location = new System.Drawing.Point(238, 134);
            this.cantidad3.Name = "cantidad3";
            this.cantidad3.Size = new System.Drawing.Size(50, 20);
            this.cantidad3.TabIndex = 25;
            // 
            // cantidad6
            // 
            this.cantidad6.Location = new System.Drawing.Point(451, 136);
            this.cantidad6.Name = "cantidad6";
            this.cantidad6.Size = new System.Drawing.Size(50, 20);
            this.cantidad6.TabIndex = 28;
            // 
            // cantidad5
            // 
            this.cantidad5.Location = new System.Drawing.Point(451, 107);
            this.cantidad5.Name = "cantidad5";
            this.cantidad5.Size = new System.Drawing.Size(50, 20);
            this.cantidad5.TabIndex = 27;
            // 
            // cantidad4
            // 
            this.cantidad4.Location = new System.Drawing.Point(451, 75);
            this.cantidad4.Name = "cantidad4";
            this.cantidad4.Size = new System.Drawing.Size(50, 20);
            this.cantidad4.TabIndex = 26;
            // 
            // ejer1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cantidad6);
            this.Controls.Add(this.cantidad5);
            this.Controls.Add(this.cantidad4);
            this.Controls.Add(this.cantidad3);
            this.Controls.Add(this.cantidad2);
            this.Controls.Add(this.cantidad1);
            this.Controls.Add(this.btnsalir);
            this.Controls.Add(this.lblresultado);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.btncancelar);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.precio6);
            this.Controls.Add(this.comprobador6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.precio5);
            this.Controls.Add(this.comprobador5);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.precio4);
            this.Controls.Add(this.comprobador4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.precio3);
            this.Controls.Add(this.comprobador3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.precio2);
            this.Controls.Add(this.comprobador2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.precio1);
            this.Controls.Add(this.comprobador1);
            this.Name = "ejer1";
            this.Text = "ejer1";
            this.Load += new System.EventHandler(this.ejer1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cantidad1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidad4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox comprobador1;
        private System.Windows.Forms.Label precio1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label precio2;
        private System.Windows.Forms.CheckBox comprobador2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label precio3;
        private System.Windows.Forms.CheckBox comprobador3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label precio6;
        private System.Windows.Forms.CheckBox comprobador6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label precio5;
        private System.Windows.Forms.CheckBox comprobador5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label precio4;
        private System.Windows.Forms.CheckBox comprobador4;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Button btncancelar;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label lblresultado;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.NumericUpDown cantidad1;
        private System.Windows.Forms.NumericUpDown cantidad2;
        private System.Windows.Forms.NumericUpDown cantidad3;
        private System.Windows.Forms.NumericUpDown cantidad6;
        private System.Windows.Forms.NumericUpDown cantidad5;
        private System.Windows.Forms.NumericUpDown cantidad4;
    }
}